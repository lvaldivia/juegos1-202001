using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.Animation.Tests.EditorTests")]
[assembly: InternalsVisibleTo("Unity.2D.PsdImporter.Editor")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
